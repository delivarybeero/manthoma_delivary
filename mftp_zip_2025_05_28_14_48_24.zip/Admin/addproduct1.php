<?php
session_start();
include("../include/connection.php");

// تأمين الجلسة وتحقق من صلاحيات المستخدم
if(!isset($_SESSION['EMAIL'])){
    header("Location: admin.php");
    exit();
}
$prosection = '';
$prounv = '';

// معالجة البيانات المرسلة
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['proadd'])) {
    
    // تنظيف المدخلات
    $proname = mysqli_real_escape_string($conn, $_POST['name']);
    $proprice = floatval($_POST['price']);
   // $prosection = mysqli_real_escape_string($conn, $_POST['prosection']);
    $prodescrip = mysqli_real_escape_string($conn, $_POST['description']);
    $prosize = mysqli_real_escape_string($conn, $_POST['prosize']);
    $prounv = mysqli_real_escape_string($conn, $_POST['prounv']);
    $quantity = intval($_POST['quantity']);
    
    // معالجة الصورة
    $uploadOk = 1;
    $imageName = basename($_FILES['image']['name']);
    $target_dir = "../uploads/img/";
    $target_file = $target_dir . uniqid() . '_' . $imageName;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // التحقق من نوع الملف
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    if(!in_array($imageFileType, $allowed_types)) {
        echo '<script>alert("فقط الصور مسموح بها: JPG, JPEG, PNG, GIF");</script>';
        $uploadOk = 0;
    }
    
    // التحقق من الأخطاء
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            
            // استخدام prepared statements
            $stmt = $conn->prepare("INSERT INTO products 
                (name, image, price, prosection, description, prosize, prounv, quantity)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->bind_param("ssdssssi", 
                $proname, 
                $target_file, 
                $proprice,
                $prosection,
                $prodescrip,
                $prosize,
                $prounv,
                $quantity);
            
            if($stmt->execute()){
                echo '<script>alert("تمت الإضافة بنجاح");</script>';
            } else {
                echo '<script>alert("خطأ في قاعدة البيانات: ' . $stmt->error . '");</script>';
            }
            $stmt->close();
        } else {
            echo '<script>alert("خطأ في تحميل الصورة");</script>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة منتج جديد</title>
    <style>
        body {font-family: Arial, sans-serif; background: #f0f0f0;}
        .container {max-width: 800px; margin: 20px auto; padding: 20px; background: white; border-radius: 8px;}
        .form-group {margin-bottom: 15px;}
        label {display: block; margin-bottom: 5px; font-weight: bold;}
        input, select, textarea {width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;}
        .button {background: #4CAF50; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;}
        .button:hover {background: #45a049;}
    </style>
</head>
<body>
    <div class="container">
        <h1>إضافة منتج جديد</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>اسم المنتج:</label>
                <input type="text" name="name" required>
            </div>

            <div class="form-group">
                <label>السعر:</label>
                <input type="number" name="price" step="0.01" required>
            </div>

            <div class="form-group">
                <label>الوصف:</label>
                <textarea name="description" required></textarea>
            </div>

            <div class="form-group">
                <label>الحجم/الوزن:</label>
                <input type="text" name="prosize" required>
            </div>

            <div class="form-group">
                <label>الكمية:</label>
                <input type="number" name="quantity" required>
            </div>
           

            <div class="form-group">
                <label>صورة المنتج:</label>
                <input type="file" name="image" accept="image/*" required>
            </div>

            <button type="submit" name="proadd" class="button">إضافة المنتج</button>
            <a href="admianpanel.php" class="button">العودة للوحة التحكم</a>
        </form>
    </div>
</body>
</html>