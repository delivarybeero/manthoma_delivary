



<style>
root {
            --primary-color: #3498db;
            --sidebar-width: 250px;
            --sidebar-bg: #2c3e50;
            --content-bg: #fff;
            --stat-box-bg: #f8f9fa;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            overflow-x: hidden;
        }