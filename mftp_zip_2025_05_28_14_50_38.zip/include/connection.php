<?php
$servername = 'sql204.infinityfree.com';
$dbname = 'if0_38974625_algoojdatabase';
$username = 'if0_38974625';
$password = 'wIMerDZZ6XNX';

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("فشل الاتصال: " . mysqli_connect_error());
}
?>